<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "folk_scenery";
	
	$conn = mysqli_connect($servername, $username, $password, $database)
	or die("Gagal koneksi ke server" .$servername);
?>